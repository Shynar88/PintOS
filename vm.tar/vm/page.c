#include "vm/page.h"

/*
 * Initialize supplementary page table
 */
void 
page_init (void)
{

}

/*
 * Make new supplementary page table entry for addr 
 */
struct sup_page_table_entry *
allocate_page (void *addr)
{

}

