#include "vm/frame.h"

/*
 * Initialize frame table
 */
void 
frame_init (void)
{

}


/* 
 * Make a new frame table entry for addr.
 */
bool
allocate_frame (void *addr)
{


}

